import { Injectable } from '@angular/core';
@Injectable()
export class ProvinceList {
    public Province_list : any = ["Eastern Cape","Free State","Gauteng","KwaZulu-Natal","Limpopo","Mpumalanga","Northern Cape","North West", "Western Cape"];
}