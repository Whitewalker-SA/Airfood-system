import { Injectable } from '@angular/core';
@Injectable()
export class ContentTypeList {
    public contentType_list: any = [
        "Image",
        "Video",
        "Document",
        "Content Link",
    ];
}